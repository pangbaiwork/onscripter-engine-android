package com.onscripter.exception;

public class NativeONSException extends Exception {
	private static final long serialVersionUID = 1L;
	
    public NativeONSException(String message) {
        super(message);
    }


    }
